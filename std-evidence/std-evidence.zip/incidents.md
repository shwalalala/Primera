# Primera Mobile Test Execution - Incidents & Defect Log

This document records architectural, functional, and behavioral discrepancies identified during the execution of the Software Test Document (STD) mobile test suite on the Android emulator (`emulator-5554`, API 34).

---

### Incident 1: Health Connect Package Check Fails on Android 14+ (API 34+)
- **Module:** 3.4 (Smartwatch Connection) & 3.5 (Smartwatch Health Data)
- **Severity:** Medium / Compatibility Defect
- **Component:** `cit.edu.primera.feature.smartwatchconnection.data.HealthConnectManager.isPackageInstalled()`
- **Observed Behavior:**
  The app checks for the existence of package `com.google.android.apps.healthdata` using `packageManager.getPackageInfo("com.google.android.apps.healthdata", ...)`. On Android 14 (API 34) and newer, Health Connect is a core Android system framework service rather than a standalone APK download from Google Play. As a result, `getPackageInfo` throws `PackageManager.NameNotFoundException`, causing the UI to display: `"Health Connect is not installed on this device."`
- **Expected Behavior:**
  On Android 14+ (API 34+), the app should check Health Connect availability via `HealthConnectClient.getSdkStatus(context, "com.google.android.apps.healthdata")` or query the platform provider rather than assuming a separate standalone package is installed.
- **Impact:**
  Prevents device pairing and sync flows on Android 14 and Android 15 devices even when Health Connect system framework is active.

---

### Incident 2: Speech Recognition Hardware Unavailable on Android Emulator
- **Module:** 3.6 (Speech to Text)
- **Severity:** Environment Limitation
- **Component:** `cit.edu.primera.feature.transcription.data.SpeechRecognitionManager`
- **Observed Behavior:**
  When microphone permission is granted and speech recognition starts, the Android emulator's virtual audio layer emits speech error code 11 (`SpeechRecognizer.ERROR_CANNOT_CHECK_SUPPORT` / audio hardware failure). The editable transcription input field in `TranscriptionScreen` is conditionally displayed only after successful voice recognition, preventing acoustic verification on emulators.
- **Resolution:**
  Marked speech acoustic recognition as `SKIPPED-MANUAL` with full manual test reproduction steps documented in `manual-todo.md`.

---

### Incident 3: Absence of Delete Action for Daily Check-In Logs in UI
- **Module:** 3.8 (Log History - Steps 7 & 8)
- **Severity:** Functional Discrepancy
- **Component:** `cit.edu.primera.feature.checkins.ui.CheckinsOverviewScreen` / `DailyCheckinDetailsSheet`
- **Observed Behavior:**
  The STD specifies deleting a daily check-in entry with a confirmation dialog (Steps 7 & 8). In the Primera app implementation, the daily check-in detail sheet only exposes an `"Edit Daily Check-In"` action and a `"Close"` button. There is no delete button or delete confirmation dialog for daily check-in records in the UI.
- **Expected Behavior:**
  A delete icon/button with confirmation dialog allowing users to remove mistaken self-reported entries.
- **Impact:**
  Steps `3.8_s7` and `3.8_s8` are recorded as `FAIL (Feature Not Present in UI)`.

---

### Incident 4: ReminderReceiver Exported Without Permissions
- **Module:** 3.22 (Security & Permissions Audit)
- **Severity:** Low / Hardening Recommendation
- **Component:** `cit.edu.primera.core.notification.ReminderReceiver` in `AndroidManifest.xml`
- **Observed Behavior:**
  `ReminderReceiver` is declared with `android:exported="true"` but contains no `<intent-filter>` and no signature permission protection.
- **Recommendation:**
  Set `android:exported="false"`. `AlarmManager` pending intents created by the same application UID do not require the receiver to be exported, preventing third-party apps from sending arbitrary alarm trigger broadcasts.
